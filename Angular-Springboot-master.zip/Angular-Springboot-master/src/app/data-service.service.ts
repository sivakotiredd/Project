import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  constructor() { }

  public values:any;

  set setValues(val:any){
        this.values=val;
  }
 
   get getValues():any{
      return this.values;
     }

}
