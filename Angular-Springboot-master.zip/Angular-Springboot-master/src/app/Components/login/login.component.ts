import { Component, OnInit,Input } from '@angular/core';
import { ApiService } from 'src/app/Service/api.service';
import { LoginserviceService } from 'src/app/Service/loginService/loginservice.service';
import { Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  private loginForm: any;
  loginData:any;
  error = false;
  constructor(private apiService: ApiService,private loginserviceService: LoginserviceService,
    private router: Router,
    private formBuilder: FormBuilder) {
    //this.createForm();
  }

  ngOnInit() {
    this.loginForm = new FormGroup({
      'username' : new FormControl(null, Validators.required),
      'password' : new FormControl(null,Validators.required)
      
    });
  }
  createForm() {

   

    // this.loginForm = this.formBuilder.group({
    //   username: '',
    //   password: ''
    // });

  }
  
  login(): void {
    //alert('Inside Login');
    this.apiService.login(this.loginForm.value).
      subscribe(res => {
        this.loginData = res;
        if(res.username != null){
          this.router.navigate(['/home']);
          this.loginserviceService.sharedData=res.username;
          this.loginserviceService.sendClickEvent();
        }
        else{
          this.router.navigate(['/login']);
          this.error=true;
        }
      },
        err => {
          alert('Inside Error');

          this.router.navigate(['/login']);
      });
  }
}