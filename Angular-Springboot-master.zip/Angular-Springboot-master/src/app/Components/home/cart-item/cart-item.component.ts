
import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/Service/api.service';
import { Cart } from 'src/app/Model/cart';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { DataServiceService } from 'src/app/data-service.service'; //importing that service
import { FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-cart-item',
  templateUrl: './cart-item.component.html',
  styleUrls: ['./cart-item.component.css']
})
export class CartItemComponent implements OnInit {

  productName : string;
  model :string;
  make :string;
  categoryId:string;
  subCategoryId:string;
  price:number;
  quantity:number;
  specification:string;
  private auth: string;
  cartlist: Cart[];
  totalSum: number = 0;
  private updateForm: any;
  constructor(private api: ApiService, private route: Router, private dataServiceService: DataServiceService, private formBuilder: FormBuilder) {
    // this.productName = this.dataServiceService.getValues.productName;
    // this.model=this.dataServiceService.getValues.model;
    // this.make=this.dataServiceService.getValues.make;
    // this.categoryId=this.dataServiceService.getValues.categoryId;
    // this.subCategoryId=this.dataServiceService.getValues.subCategoryId;
    // this.price=this.dataServiceService.getValues.price;
    // this.quantity=this.dataServiceService.getValues.quantity;
    // this.specification=this.dataServiceService.getValues.specification;
    this.createForm();
  }

  
  ngOnInit() {
    this.api.getCartItems().subscribe(res => {
      this.cartlist = res.oblist;
      this.cartlist.forEach(value => {
        this.totalSum = this.totalSum + (value.quantity * value.price);
      });
    });

  }
  // updateCart(id:any, quantity:any) {
  //   this.api.updateCartItem(id.value, quantity.value).subscribe(res => {
  //     this.cartlist = res.oblist;
  //     this.cartlist.forEach(value => {
  //       this.totalSum = this.totalSum + (value.quantity * value.price);
  //     });
  //   });
  // }
  createForm() {
    this.updateForm = this.formBuilder.group({
      productId:this.dataServiceService.values.productId,
      productName :this.dataServiceService.values.productName,
      model:this.dataServiceService.values.model,
      make:this.dataServiceService.values.make,
      categoryId:this.dataServiceService.values.categoryId,
      subCategoryId:this.dataServiceService.values.subCategoryId,
      price:this.dataServiceService.values.price,
      quantity:this.dataServiceService.values.quantity,
      specification:this.dataServiceService.values.specification
    });
   }
  

  updateProduct() {
    //alert("get method diff componentzzzzz:"+JSON.stringify(this.dataServiceService.getValues));
   // alert("it will work productName:"+JSON.stringify(this.productName));
  // alert("here in side before calling backend "+JSON.stringify(this.updateForm.value.productId));
   // this.apiService.addProduct(this.productForm.value).
   //this.updateForm.value
     this.api.UpdateProductDetails(this.updateForm.value).subscribe(res => {
    //  alert("Response "+JSON.stringify(res)); 
     // this.route.navigate(['/home']);
     if (res.code == "201") {
      alert(JSON.stringify(res.messgae));

    } else{
      this.route.navigate(['/home']);
    }
   });
  }

  deleteItem(id:any) {
    this.api.deleteCartItem(id.value).subscribe(res => {
      this.cartlist = res.oblist;
      this.cartlist.forEach(value => {
        this.totalSum = this.totalSum + (value.quantity * value.price);
      });
    });
  }

  placeOrder() {
    this.api.placeOrder().subscribe(res => {
      console.log(res);
    });
    this.route.navigate(['/home']);
  }

}

