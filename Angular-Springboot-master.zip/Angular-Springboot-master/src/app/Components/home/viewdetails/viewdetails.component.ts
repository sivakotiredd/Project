import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { ApiService } from 'src/app/Service/api.service';



@Component({
  selector: 'app-viewdetails',
  templateUrl: './viewdetails.component.html',
  styleUrls: ['./viewdetails.component.css']
})
export class ViewDetailsComponent implements OnInit {
  private viewdetailsForm: any;
  private data:any;
  productId : any= sessionStorage.getItem("prodId");
  //alert("ProductId"+prodId.value);
  constructor(private apiService: ApiService,
    private router: Router,
    private formBuilder: FormBuilder) {
    //this.createForm();
  }

  ngOnInit() {
   // alert("before calling api");
    this.apiService.getproductDetailsById(this.productId).subscribe(res => {
      this.data = res;
          //alert(JSON.stringify(res));
         //this.router.navigate(['/home']);
        // }

      },
         err => {
           alert("An error has occured, Please try again !!!");
        });
  }
}