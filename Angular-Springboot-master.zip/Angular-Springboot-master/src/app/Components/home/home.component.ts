import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/Service/api.service';
import { Product } from 'src/app/Model/product';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { DataServiceService } from 'src/app/data-service.service'; //importing that service


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  response = null;
  deleteProductResponse = null;
  products: Product[] = [];
  private productForm: any;
  error = false;
  constructor(private apiService: ApiService,
    private router: Router,
    private dataServiceService: DataServiceService,
    private formBuilder: FormBuilder) {
    this.createForm();
  }


  createForm() {
    this.productForm = this.formBuilder.group({
      username: ''
    });

  }
  ngOnInit() {
    //alert('Inside Home');
    this.apiService.getProducts(this.productForm.value).
      subscribe(res => {
        this.response = res;
        // alert(JSON.stringify(res));
        this.router.navigate(['/home']);
      },
        err => {
          alert('Inside Error');

          this.router.navigate(['/login']);
        });
  }


  navigateToProduct(product) {
    //alert("inside navigate prouct");
    this.dataServiceService.setValues = product;
    this.router.navigate(['/home/cart']);
  }
  deleteItem(prodId: any) {
    //alert("ProductId " + prodId.value);

    this.apiService.deleteCartItem(prodId.value).subscribe(res => {
     alert("Delete Product"+JSON.stringify(res));
      this.deleteProductResponse = JSON.stringify(res);
      var deleteResponse = this.deleteProductResponse;
      //  if(deleteResponse.code == "200"){
          this.ngOnInit();
          //alert(""+deleteResponse.messgae);
        //}else{
         // alert(""+deleteResponse.messgae);
       // }
      
    //  this.ngOnInit();
    //  this.router.navigate(['/home']);

    });

  }
  viewDetails(prodId: any) {
    //alert("ProductId" + prodId.value);
    sessionStorage.setItem("prodId", prodId.value);
    this.router.navigate(['view/details']);
  }
}


























