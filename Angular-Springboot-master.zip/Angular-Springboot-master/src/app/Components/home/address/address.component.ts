import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { ApiService } from 'src/app/Service/api.service';
import { LoginserviceService } from 'src/app/Service/loginService/loginservice.service';




@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit {
  private productForm: any;
  loginData: string;
  constructor(private apiService: ApiService,private loginserviceService: LoginserviceService,
    private router: Router,
    private formBuilder: FormBuilder) {
      this.loginData = this.loginserviceService.sharedData;
    this.createForm();
    console.log(this.loginData);
  }

  ngOnInit() {
  }
  createForm() {
    this.productForm = this.formBuilder.group({
      productName: '',
      model: '',
      make: '',
      categoryId: '',
      subCategoryId: '',
      price: '',
      quantity: '',
      specification: '',
      status: 'true',
      userName: this.loginData
    });
  }
  addProduct(): void {
    //alert("before calling api");
    //alert('Inside Register'+JSON.stringify(this.productForm.value));
     this.apiService.addProduct(this.productForm.value).
       subscribe(res => {

        alert(JSON.stringify(res));
        if (res.code == "201") {
          alert(JSON.stringify(res.messgae));
    
        } else{
          this.router.navigate(['/home']);
        }
    //     alert('Inside add prod' + JSON.stringify(res));
    //     // if (res.status == "400") {
    //     //   console.log("Details cannot be empty");
    //     // } else {
         //this.router.navigate(['/home']);
        // }

      },
         err => {
           alert("An error has occured, Please try again !!!");
        });
  }

}
