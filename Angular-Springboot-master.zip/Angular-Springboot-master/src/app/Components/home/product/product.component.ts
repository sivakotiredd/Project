import { Component, OnInit, Input, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from 'src/app/Model/product';
import { EventEmitter } from '@angular/core';
import { ApiService } from 'src/app/Service/api.service';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';




@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  @Input() public product;

  @Output() productAddToCart: EventEmitter<Product> = new EventEmitter<Product>();
//  constructor(private http: HttpClient) { }
private addProductForm: any;
error = false;

  constructor(private apiService: ApiService,
    private router: Router,
    private formBuilder: FormBuilder) {
    //this.createForm();
  }

  ngOnInit() {

  }

  addToCart() {
    this.productAddToCart.emit(this.product);
  }
  createForm() {
    this.addProductForm = this.formBuilder.group({
      username: ''
     // password: ''
    });

  }

  addProduct(): void {
    //alert('Inside Product');

    this.apiService.login(this.addProductForm.value).
      subscribe(res => {

        alert(JSON.stringify(res));
        if (res.code == "201") {
          alert(JSON.stringify(res.messgae));
    
        } else{
          this.router.navigate(['/login']);
        }
      //  if (res.status == "200" && res.userType == "CUSTOMER") {
        //  this.apiService.storeToken(res.authToken, "customer");
         // this.router.navigate(['/login']);
         // this.error = false;
       // } else if (res.status == "200" && res.userType == "ADMIN") {
         // this.apiService.storeToken(res.authToken, "admin");
         // this.router.navigate(['/admin']);
         // this.error = false;
     //   }
      },
        err => {
          this.router.navigate(['/login']);
      });
  }

}
