import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/Service/api.service';
import { Router } from '@angular/router';
import { LoginserviceService } from 'src/app/Service/loginService/loginservice.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
  private loggedType: string;
  loginData: string;
  validUser: Boolean = false;
  constructor(private auth: ApiService, private loginserviceService: LoginserviceService, private route: Router) {
    this.loginData = this.loginserviceService.sharedData;
    // if (this.auth.getAuthType() == null) {
    //   this.loggedType = "home";
    // } else {
    //   if (this.auth.getAuthType() == "customer") {
    //     this.loggedType = "customer";
    //   } else if (this.auth.getAuthType() == "admin") {
    //     this.loggedType = "admin";
    //   }
    // }
  }
  ngOnInit() {
    console.log(this.loginData);
    this.loggedType = "login";
    this.loginserviceService.sendClickEvent();
    {
      if (this.loginData != null) {
        this.validUser = true;
      }
    }
  }
  logout() {
    this.validUser = false;
  //  this.loginData = null;
    this.route.navigate(['/login']);
    alert('User Logged out Successfully');
    
  }

}