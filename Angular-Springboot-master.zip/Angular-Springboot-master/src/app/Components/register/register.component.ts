import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/Service/api.service';
import { Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators, FormControl } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  exform: FormGroup;
  constructor(private apiService: ApiService,
    private router: Router,
    private formBuilder: FormBuilder) {
  }

  ngOnInit() {

  this.exform = new FormGroup({
    'userName' : new FormControl(null, Validators.required),
    'address' : new FormControl(null, [Validators.required, Validators.minLength(10)]),
    'sellerName' : new FormControl(null,Validators.required),
    'password' : new FormControl(null,[Validators.required,Validators.minLength(6)]), 
    'emailId' : new FormControl(null, [Validators.required, Validators.email]),
    'phoneNumber' : new FormControl(
      null,
      [
        Validators.required,
        Validators.pattern('^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$')
      ]),
    
  });
  }

  clicksub() {
     this.apiService.register(this.exform.value).
    subscribe(res => {
       alert('Inside Register'+JSON.stringify(res));
         this.router.navigate(['/login']);     
    },
      err => {
        alert("An error has occured, Please try again !!!");
      });
    this.exform.reset();
  }
  get userName() {
    return this.exform.get('userName');
  }
  get emailId() {
    return this.exform.get('emailId');
  }
  get phoneNumber() {
    return this.exform.get('phoneNumber');
  }
  get address() {
    return this.exform.get('address');
  }

  get password(){
    return this.exform.get('password');
  }

  get sellerName(){
    return this.exform.get('sellerName');
  }




}

