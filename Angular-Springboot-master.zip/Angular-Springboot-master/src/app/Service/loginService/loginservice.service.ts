import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {
  sharedData:string;
  validUser:Boolean;
  constructor() { }
  sendClickEvent() {
  this.validUser=true;
  }
}
