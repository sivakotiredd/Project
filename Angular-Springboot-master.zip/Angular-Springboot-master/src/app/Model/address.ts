export interface Address {
	productName: string;
	model: string;
	make: string;
	categoryId: string;
	subCategoryId: string;
	price: number;
	quantity: number;
	specification: string;
	status:boolean;
	userName:String;
}
