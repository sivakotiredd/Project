// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  baseUrl:"http://localhost:8998",
  signupUrl : "/seller/createSellerAccount",
  loginUrl : "/seller/sellerLogin",
  addToCartUrl : "/user/addToCart",
  viewCartUrl : "/user/viewCart",
  updateCartUrl : "/user/updateCart",
 // deleteCartUrl: "/user/delCart",
  deleteCartUrl: "/seller/deleteProduct",
 
 // addAddressUrl : "/user/addAddress",
  viewAddressUrl : "/user/getAddress",
 // productsUrl : "/user/getProducts",
  productsUrl : "/seller/getAllProduct",
  addProductUrl : "/admin/addProduct",
  deleteProductUrl : "/admin/delProduct",
  updateProduct: "/seller/updateProduct",
  updateProductUrl : "/admin/updateProducts",
  viewOrderUrl : "/admin/viewOrders",
  updateOrderUrl : "/admin/updateOrder",
  placeOrderUrl : "/user/placeOrder",
  logoutUrl : "/home/logout",
  getProductUrl:"/seller/getAllProduct",
  addProduct:"/seller/addProduct",
  getProductById:"/seller/getProductbyId"
};

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error',  // Included with Angular CLI.
