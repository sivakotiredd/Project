package com.seller.seller.model;

public class SellerCreateAccountRequestDto {
	
	/*id - Integer(Not Null and Primary Key serial)
name - Varchar 2000 (Not Null)
username - varchar 2000( Not Null)
password - Varchar 2000 (Not Null)
address - varchar 2000
emailid - Varchar 2000 (Not Null)
phone number - Long */
	
	private String sellerName;
	
	private String userName;
	
	private String password;
	
	private String address;
	
	private String emailId;
	
	private long phoneNumber;

	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "sellerCreateAccountRequestDto [sellerName=" + sellerName + ", userName=" + userName + ", password="
				+ password + ", address=" + address + ", emailId=" + emailId + ", phoneNumber=" + phoneNumber + "]";
	}
	
	
	

}
