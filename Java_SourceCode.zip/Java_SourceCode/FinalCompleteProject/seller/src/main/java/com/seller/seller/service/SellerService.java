package com.seller.seller.service;

import com.seller.seller.model.SellerCreateAccountRequestDto;
import com.seller.seller.model.SellerLoginRequestDto;
import com.seller.seller.model.SellerLoginResponseDto;

public interface SellerService {
	
	public boolean createSeller(SellerCreateAccountRequestDto request);
	
	public SellerLoginResponseDto checkSellerLogin(SellerLoginRequestDto sellerRequest);

}
