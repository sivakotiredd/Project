package com.seller.seller.service;

import java.util.List;

import com.seller.seller.model.AddProductRequestDto;
import com.seller.seller.model.AllProductListReponseDto;
import com.seller.seller.model.GetProductReponseDto;
import com.seller.seller.model.UpdateProductRequestDto;

public interface ProductService {

	public boolean addProduct(AddProductRequestDto req);
	
	public List<AllProductListReponseDto> getAllProduct();
	
	public List<AllProductListReponseDto> getAllProductForSeller(String username);
	
	public boolean deleteProduct(int productId);
	
	public GetProductReponseDto getProductById(int productId);
	
	public Boolean updateProduct(UpdateProductRequestDto product);
	
	public List<GetProductReponseDto> getSeachByProductKeywords(String productName);
	
}
