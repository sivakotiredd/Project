package com.seller.seller.repositorydao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.util.Streamable;

import com.seller.seller.model.Product;

public interface ProductDao extends JpaRepository<Product, Integer> {
	
	/*@Query(value = "SELECT product_id from product WHERE product_name = ?1", nativeQuery = true)
	public Collection<Product> getProductByKewords(String productName);*/
	
	 Streamable<Product> findByProductNameContaining(String firstname);
	  
	 @Query("select p from Product p join p.seller s Where s.username = :userName")
	 public List<Product> getAllProductByUsername(@Param("userName") String userName);
   
	 
	 //select b.fname, b.lname from Users b JOIN b.groups c where c.groupName = :groupName
	
}
