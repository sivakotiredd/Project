package com.seller.seller.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.seller.seller.model.AddProductRequestDto;
import com.seller.seller.model.AddProductResponseDto;
import com.seller.seller.model.AllProductListReponseDto;
import com.seller.seller.model.GetAllProductReqDto;
import com.seller.seller.model.GetProductReponseDto;
import com.seller.seller.model.Product;
import com.seller.seller.model.SellerCreateAccountRequestDto;
import com.seller.seller.model.SellerCreateAccountResponseDto;
import com.seller.seller.model.SellerLoginRequestDto;
import com.seller.seller.model.SellerLoginResponseDto;
import com.seller.seller.model.UpdateProductRequestDto;
import com.seller.seller.model.UpdateProductResponseDto;
import com.seller.seller.service.ProductService;
import com.seller.seller.service.ProductServiceImpl;
import com.seller.seller.service.SellerService;

@RestController
@RequestMapping("/seller")
@CrossOrigin
public class SellerController {
	
	@Autowired
	SellerService sellerService;
	
	@Autowired
	ProductService productService;
	
	
	/*@PostMapping("/createSellerAccount")
	public SellerCreateAccountResponseDto createSellerAcct(@RequestBody SellerCreateAccountRequestDto sellerRequest) {
		
		SellerCreateAccountResponseDto response = new SellerCreateAccountResponseDto();
		
		boolean isSave = sellerService.createSeller(sellerRequest);
		if( isSave == true) {
		response.setCode("200");
		response.setMessgae("seller created successfully");
		} else {
			response.setCode("201");
			response.setMessgae("seller not created");
		}
		
		return response;
	}*/
	
	@PostMapping("/createSellerAccount")
	public SellerCreateAccountResponseDto createSellerAcct(@RequestBody SellerCreateAccountRequestDto sellerRequest) {
	SellerCreateAccountResponseDto response = new SellerCreateAccountResponseDto();
	if(sellerRequest.getSellerName()==null || sellerRequest.getSellerName()=="" ) {
	response.setCode("201");
	response.setMessgae("Please Provide Seller Name");
	return response;
	}else if(sellerRequest.getUserName()==null || sellerRequest.getUserName()=="") {
	response.setCode("201");
	response.setMessgae("Please Provide User Name");
	return response;
	}else if(sellerRequest.getAddress() == null|| sellerRequest.getAddress() =="") {
	response.setCode("201");
	response.setMessgae("Please Provide Address");
	return response;
	}else if(sellerRequest.getEmailId()==null || sellerRequest.getEmailId()=="") {
	response.setCode("201");
	response.setMessgae("Please Provide Email Id");
	return response;
	}else if(sellerRequest.getPassword() == null ||( sellerRequest.getPassword() == "")) {
	response.setCode("201");
	response.setMessgae("Please Provide Password");
	return response;
	}else if((sellerRequest.getPassword().length()<6)&& (sellerRequest.getPassword().length() >=1)) {
	response.setCode("201");
	response.setMessgae("Password must be equal to or greater than 6 digits");
	return response;
	}
	else {
	boolean isSave = sellerService.createSeller(sellerRequest);
	if( isSave == true) {
	response.setCode("200");
	response.setMessgae("seller created successfully");
	} else {
	response.setCode("201");
	response.setMessgae("seller not created");
	}
	}
	return response;
	}


	
	
	@PostMapping("/addProduct")
	public AddProductResponseDto  addProduct(@RequestBody  AddProductRequestDto  addProductRequest) {
		
		AddProductResponseDto response = new AddProductResponseDto();
		
		if(addProductRequest.getProductName()==null || addProductRequest.getProductName()=="" ) {
			response.setCode("201");
			response.setMessgae("Please Provide Product Name");
			return response;
		}else if(addProductRequest.getModel()==null || addProductRequest.getModel()=="") {
			response.setCode("201");
			response.setMessgae("Please Provide Product Model");
			return response;
		}else if(addProductRequest.getMake()==null  || addProductRequest.getMake()=="") {
			response.setCode("201");
			response.setMessgae("Please Provide Product Manufacturer");
			return response;
		}/*else if(addProductRequest.getCategoryId()==null || addProductRequest.getCategoryId()=="") {
			response.setCode("201");
			response.setMessgae("Please Provide Product Category");
			return response;
		}*//*else if(addProductRequest.getSubCategoryId()==null || addProductRequest.getSubCategoryId()=="") {
			response.setCode("201");
			response.setMessgae("Please Provide Product Sub Category");
			return response;
		}*/else if(addProductRequest.getPrice()<=0) {
			response.setCode("201");
			response.setMessgae("Please Provide Product Price");
			return response;
		}else if(addProductRequest.getQuantity()<=0) {
			response.setCode("201");
			response.setMessgae("Please Provide Product Quantity");
			return response;
		}else if(addProductRequest.getSpecification()==null|addProductRequest.getSpecification()=="") {
			response.setCode("201");
			response.setMessgae("Please Provide Product Specification");
			return response;
		}
		else {
		 
		boolean isSave=productService.addProduct(addProductRequest);
		
		if(isSave == true) {
			response.setCode("200");
			response.setMessgae("product added");
		} else {
			response.setCode("201");
			response.setMessgae("product is not created");	
		}
		}
		return response;
	}
	

	@PostMapping("/getAllProduct")
	public List<AllProductListReponseDto>  getAllProduct(@RequestBody GetAllProductReqDto req) {
		
		List<AllProductListReponseDto> productList = new ArrayList<AllProductListReponseDto>();
		
		try {
			
			if(req.getUsername() == null || req.getUsername().trim().length() == 0 ) {
				productList =productService.getAllProduct();
			} else {
				
				productList =productService.getAllProductForSeller(req.getUsername());
			}
				
		} catch (Exception e) {
		
		}
		
		return productList;
	}
	
	@GetMapping("/deleteProduct")
	public String deleteProduct(@RequestParam int productId ) {
		
		
		boolean isSave = productService.deleteProduct(productId);
		if(isSave == true) {
			System.out.println("product deleted");
		return "product deleted";
		} else {
		return "product is not deleted";	
		}
		
	}
	
	@GetMapping("/getProductbyId")
	public GetProductReponseDto getProductById(@RequestParam int productId ) {
		
		GetProductReponseDto productDetailResponse = productService.getProductById(productId);
		return productDetailResponse;
	}
	
	@PostMapping("/sellerLogin")
	public SellerLoginResponseDto checkSellerLogin(@RequestBody SellerLoginRequestDto request ) {
		System.out.println("inside login username:"+request.getUsername()+" pass:"+request.getPassword());
		SellerLoginResponseDto response = sellerService.checkSellerLogin(request);
		System.out.println("response:"+response);
		return response;
	}
	
	@PostMapping(value = "/updateProduct")
	public UpdateProductResponseDto updateProduct(@RequestBody UpdateProductRequestDto product) {
		UpdateProductResponseDto response = new UpdateProductResponseDto();
		System.out.println("req"+product.getPrice());
		if(product.getProductName() == null || product.getProductName() =="") {
			response.setCode("201");
			response.setMessgae("please provide Product Name");
			return response;
		}else if(product.getModel()==null || product.getModel()==""){
			response.setCode("201");
			response.setMessgae("please provide Model");
			return response;
		}else if(product.getMake()==null || product.getMake() == "") {
			response.setCode("201");
			response.setMessgae("please provide Make");
			return response;
		}else if(product.getCategoryId()==null || product.getCategoryId() == "") {
			response.setCode("201");
			response.setMessgae("please provide Category");
			return response;
		}else if(product.getPrice()==0) {
			response.setCode("201");
			response.setMessgae("please provide Price of Product");
			return response;
		}else if(product.getQuantity()<=0 ) {
			response.setCode("201");
			response.setMessgae("please provide Quantity");
			return response;
		} else if(product.getSpecification() == null || product.getSpecification()=="" ) {
			response.setCode("201");
			response.setMessgae("please provide Specification");
			return response;
		}
		else {
		boolean isSave	=	productService.updateProduct(product);
		if(isSave == true) {
			response.setCode("200");
			response.setMessgae("product is updated");
			response.setProductId(product.getProductId());
			response.setProductName(product.getProductName());
			response.setCategoryId(product.getCategoryId());
			response.setImage(product.getImage());
			response.setMake(product.getMake());
			response.setModel(product.getModel());
			response.setPrice(product.getPrice());
			response.setProductName(product.getProductName());
			response.setQuantity(product.getQuantity());
			response.setSpecification(product.getSpecification());
			response.setStatus(product.isStatus());
			response.setSubcategoryId(product.getSubCategoryId());
			
		} else {
			response.setCode("201");
			response.setMessgae("product is not updated");	
		}
		}

		
		return response;
	}
	
	@GetMapping("/getProductbyKeywords")
	public List<GetProductReponseDto> seachByProductKeywords(@RequestParam String productName ) {
		
		List<GetProductReponseDto> Response = productService.getSeachByProductKeywords(productName);
		//return productDetailResponse;
		System.out.println(Response);
		return Response;
	}
	
	
}
