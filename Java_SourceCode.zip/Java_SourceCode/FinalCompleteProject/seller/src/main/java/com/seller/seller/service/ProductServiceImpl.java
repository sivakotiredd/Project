package com.seller.seller.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

import com.seller.seller.model.AddProductRequestDto;
import com.seller.seller.model.AllProductListReponseDto;
import com.seller.seller.model.GetProductReponseDto;
import com.seller.seller.model.Product;
import com.seller.seller.model.Seller;
import com.seller.seller.model.UpdateProductRequestDto;
import com.seller.seller.repositorydao.ProductDao;
import com.seller.seller.repositorydao.SellerDao;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao productDao;
	
	@Autowired
	SellerDao sellerDao;
	
	public boolean addProduct(AddProductRequestDto req) {
		
		
		
		boolean isSave= false;
		
		try {
		Product product = new Product();
		product.setCategoryId(req.getCategoryId());
		product.setImage(req.getImage());
		product.setMake(req.getMake());
		product.setModel(req.getModel());
		product.setPrice(req.getPrice());
		product.setProductName(req.getProductName());
		product.setQuantity(req.getQuantity());
		product.setSpecification(req.getSpecification());
		product.setStatus(req.isStatus());
		product.setSubcategoryId(req.getSubCategoryId());
	    Seller seller =sellerDao.findIdByUserName(req.getUserName());
		product.setSeller(seller);
		productDao.save(product); 
		isSave=true;
		} catch(Exception e) {
		isSave=false;	
		}
		
		return isSave;
	}

public Boolean updateProduct(UpdateProductRequestDto req) {
		
		boolean isSave= false;
			
		List<Product> list = productDao.findAll();
		for(Product p: list) {			
			if(p.getProductId() == req.getProductId()) {			
			
		 try {
				
			Product product = new Product();
			product.setProductId(req.getProductId());
			product.setCategoryId(req.getCategoryId());
			product.setImage(req.getImage());
			product.setMake(req.getMake());
			product.setModel(req.getModel());
			product.setPrice(req.getPrice());
			product.setProductName(req.getProductName());
			product.setQuantity(req.getQuantity());
			product.setSpecification(req.getSpecification());
			product.setStatus(req.isStatus());
			product.setSubcategoryId(req.getSubCategoryId());
			Seller seller =sellerDao.findIdByUserName(req.getUsername());
			product.setSeller(seller);
			productDao.save(product); 
			isSave=true;
			} catch(Exception e) {
			isSave=false;	
			}
						
		}

		}
		return isSave;
		}			
		
	
	public List<AllProductListReponseDto> getAllProduct() {
		
		List<AllProductListReponseDto> productResponseList = new ArrayList<AllProductListReponseDto>();
		
		List<Product> productList=productDao.findAll();
		
		AllProductListReponseDto productResponse=null;
		
		for(Product p: productList) {
			productResponse= new AllProductListReponseDto();
			
			productResponse.setSeller(p.getSeller());
			productResponse.setCategoryId(p.getCategoryId());
			productResponse.setImage(p.getImage());
			productResponse.setMake(p.getMake());
			productResponse.setModel(p.getModel());
			productResponse.setPrice(p.getPrice());
			productResponse.setProductId(p.getProductId());
			productResponse.setProductName(p.getProductName());
			productResponse.setQuantity(p.getQuantity());
			productResponse.setSeller(p.getSeller());
			productResponse.setSpecification(p.getSpecification());
			productResponse.setStatus(p.isStatus());
			productResponse.setSubcategoryId(p.getSubcategoryId());
			
			
			productResponseList.add(productResponse);
			}
		
		
	
		return productResponseList;
	}


	public boolean deleteProduct(int productId) {
		boolean isSave=false;
		try {
		productDao.deleteById(productId);
		isSave =true;
		} catch (Exception e) {
		isSave= false;	
		}
		return isSave;
	}


	public GetProductReponseDto getProductById(int productId) {
		
		GetProductReponseDto response= new GetProductReponseDto();
		
		try {
		Optional<Product> p=productDao.findById(productId);
		Product product=p.get();
		response.setCategoryId(product.getCategoryId());
		response.setImage(product.getImage());
		response.setMake(product.getMake());
		response.setModel(product.getModel());
		response.setPrice(product.getPrice());
		response.setProductId(product.getProductId());
		response.setProductName(product.getProductName());
		response.setQuantity(product.getQuantity());
		response.setSeller(product.getSeller());
		response.setSpecification(product.getSpecification());
		response.setStatus(product.isStatus());
		response.setSubcategoryId(product.getSubcategoryId());
		
		} catch (Exception e) {
			response=null;
		}
		
		
		return response;
	}


	public List<AllProductListReponseDto> getAllProductForSeller(String username) {
		
      List<AllProductListReponseDto> productResponseList = new ArrayList<AllProductListReponseDto>();
		
     
		List<Product> productList=productDao.getAllProductByUsername(username);
		
		AllProductListReponseDto productResponse=null;
		
		for(Product p: productList) {
			productResponse= new AllProductListReponseDto();
			
			productResponse.setSeller(p.getSeller());
			productResponse.setCategoryId(p.getCategoryId());
			productResponse.setImage(p.getImage());
			productResponse.setMake(p.getMake());
			productResponse.setModel(p.getModel());
			productResponse.setPrice(p.getPrice());
			productResponse.setProductId(p.getProductId());
			productResponse.setProductName(p.getProductName());
			productResponse.setQuantity(p.getQuantity());
			productResponse.setSeller(p.getSeller());
			productResponse.setSpecification(p.getSpecification());
			productResponse.setStatus(p.isStatus());
			productResponse.setSubcategoryId(p.getSubcategoryId());
			
			
			productResponseList.add(productResponse);
			}
		
		
	
		return productResponseList;
	}

	public List<GetProductReponseDto> getSeachByProductKeywords(String productName) {
		
        List<Integer> list = new ArrayList<Integer>();
		
		try {
			 list = new ArrayList<Integer>();
			Streamable<Product> result = productDao.findByProductNameContaining(productName);
			
		    Stream<Product> product=result.get();
			Iterator<Product> p=product.iterator();
			
			while(p.hasNext()) {
				list.add(p.next().getProductId());
			}   
			
		}catch(Exception e) {
		//	System.out.println("e "+e);
		}
		
		System.out.println("list "+list);
		
		//Product prod = productDao.getById(p.next().getProductId());
		//System.out.println("a "+prod.getImage());
		//System.out.println("a "+prod.getPrice());
		
		List<GetProductReponseDto> responseList= new ArrayList<GetProductReponseDto>();
		GetProductReponseDto response=null;
		for(int id:list) {
			response = new GetProductReponseDto();
			Product product = productDao.getById(id);
			response.setCategoryId(product.getCategoryId());
			response.setImage(product.getImage());
			response.setMake(product.getMake());
			response.setModel(product.getModel());
			response.setPrice(product.getPrice());
			response.setProductId(product.getProductId());
			response.setProductName(product.getProductName());
			response.setQuantity(product.getQuantity());
			response.setSeller(product.getSeller());
			response.setSpecification(product.getSpecification());
			response.setStatus(product.isStatus());
			response.setSubcategoryId(product.getSubcategoryId());
			responseList.add(response);
		}
		
		
		return responseList;
	}
	
	

}
