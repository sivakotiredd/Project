package com.seller.seller.model;

public class AddProductRequestDto {
	
	/*id - Integer (Not null and primary key serial)
name - Not null (Varchar 2000)
model - (Varchar 2000)
make - (Varchar 2000)
category id - (Varchar 2000)
sub category id - (Varchar 2000)
price - Not Null (Decimal)
quantity - Not Null (Integer)
image - Blob
specifications - Varchar 2000
seller id - Integer Not Null ( foreign key )
status(active/inactive) - Boolean Not Null*/
	
	private String productName;
	
	private String model;
	
	private String make;
	
	private String categoryId;
	
	private String subCategoryId;
	
	private int price;
	
	private int quantity;
	
	private String image;
	
	private String specification;
	
	private String userName;
	
	private boolean status;
	
	

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	

	

	

	


	
	

		

}
