package com.seller.seller.model;

public class AddProductResponseDto {
	
    private String code;
	
	private String messgae;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessgae() {
		return messgae;
	}

	public void setMessgae(String messgae) {
		this.messgae = messgae;
	}

	@Override
	public String toString() {
		return "AddProductResponseDto [code=" + code + ", messgae=" + messgae + "]";
	}
	
	

}
