package com.seller.seller.repositorydao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.seller.seller.model.Seller;


public interface SellerDao extends JpaRepository<Seller, Integer> {
	
	@Query("From Seller s Where s.username = :userName")
	public Seller findIdByUserName(@Param("userName") String userName);
	
	@Query("select count(s) From Seller s Where s.username = :userName and s.password = :password")
	public int findByUsernamePassword(@Param("userName") String userName , @Param("password") String password);  
	
	

}
