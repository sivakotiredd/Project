package com.seller.seller.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seller.seller.model.Seller;
import com.seller.seller.model.SellerCreateAccountRequestDto;
import com.seller.seller.model.SellerLoginRequestDto;
import com.seller.seller.model.SellerLoginResponseDto;
import com.seller.seller.repositorydao.SellerDao;


@Service
public class SellerServiceImpl implements SellerService {

	
	@Autowired
	SellerDao sellerDao;
	
	public boolean createSeller(SellerCreateAccountRequestDto request) {
		
		boolean isSave=false;
		
		try {
		
		Seller seller = new Seller();
		seller.setAddress(request.getAddress());
		seller.setEmailId(request.getEmailId());
        seller.setName(request.getSellerName());
        seller.setPassword(request.getPassword());
        seller.setPhoneNumber(request.getPhoneNumber());
        seller.setUsername(request.getUserName());
        sellerDao.save(seller);
        isSave=true;
		} catch (Exception e ) {
			isSave=false;	
		}
	  return isSave;
	}

	public SellerLoginResponseDto checkSellerLogin(SellerLoginRequestDto sellerRequest) {
		boolean isValid=false;
		SellerLoginResponseDto response = new SellerLoginResponseDto();
		try {
		int count = sellerDao.findByUsernamePassword(sellerRequest.getUsername(),sellerRequest.getPassword());
			if(count ==1) {
			isValid = true;
			}
		} catch (Exception e) {
		isValid	= false;
		}
		
		response.setValidCred(isValid);
		
		if(isValid == true) {
			
			 Seller seller =sellerDao.findIdByUserName(sellerRequest.getUsername());
			 
			 response.setAddress(seller.getAddress());
			 response.setEmailId(seller.getEmailId());
			 response.setName(seller.getName());
			 response.setPhoneNumber(seller.getPhoneNumber());
			 response.setSellerId(seller.getSellerId());
			 response.setUsername(seller.getUsername());
			 response.setValidCred(isValid);
			 
			
		}
		
		
		return response;
	}

}
