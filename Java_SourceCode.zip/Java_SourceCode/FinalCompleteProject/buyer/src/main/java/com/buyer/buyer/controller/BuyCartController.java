package com.buyer.buyer.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.buyer.buyer.model.AddCheckoutResponseDto;
import com.buyer.buyer.model.AddcartRequestDto;
import com.buyer.buyer.model.AllProductListReponseDto;
import com.buyer.buyer.model.BuyerCreateAccountRequestDto;
import com.buyer.buyer.model.BuyerCreateAccountResponseDto;
import com.buyer.buyer.model.BuyerLoginRequestDto;
import com.buyer.buyer.model.BuyerLoginResponseDto;
import com.buyer.buyer.model.Cart;
import com.buyer.buyer.model.Checkout;
import com.buyer.buyer.model.CheckoutResponseDto;
import com.buyer.buyer.model.GetAllProductReqDto;
import com.buyer.buyer.model.GetProductReponseDto;
import com.buyer.buyer.service.BuyerService;
import com.google.gson.Gson;


@RestController
@RequestMapping("/buyer")
public class BuyCartController {
	@Autowired
	BuyerService buyerService;
	
	
	
	@PostMapping("/createBuyerAccount")
	public BuyerCreateAccountResponseDto createSellerAcct(@RequestBody BuyerCreateAccountRequestDto sellerRequest) {
		
		BuyerCreateAccountResponseDto response = new BuyerCreateAccountResponseDto();
		
		boolean isSave = buyerService.createSeller(sellerRequest);
		if( isSave == true) {
		response.setCode("200");
		response.setMessgae("buyer created successfully");
		} else {
			response.setCode("201");
			response.setMessgae("buyer not created");
		}
		
		return response;
	}
	
	@PostMapping("/addCart")
	public BuyerCreateAccountResponseDto  addProduct(@RequestBody  AddcartRequestDto  addcartRequestDto) {
		
		BuyerCreateAccountResponseDto response = new BuyerCreateAccountResponseDto();
		 
		boolean isSave=buyerService.addProduct(addcartRequestDto);
		
		if(isSave == true) {
			response.setCode("200");
			response.setMessgae("product added");
		} else {
			response.setCode("201");
			response.setMessgae("product is not created");	
		}
	
		return response;
	}
	@GetMapping(value = "/cart/view/{id}")
	public List<Cart> findByAge(@PathVariable int id) {

		List<Cart> customers = buyerService.findByBuyerId(id);
		return customers;
	}
	
	
	@GetMapping("/deleteCart")
	public String deleteCart(@RequestParam int cartId) {
		boolean isSave = buyerService.deleteCart(cartId);
		if(isSave == true) {
		return "cart deleted";
		} else {
		return "cart is not deleted";	
		}
		
	}
	
	
	@PostMapping("/buyerLogin")
	public BuyerLoginResponseDto checkBuyerLogin(@RequestBody BuyerLoginRequestDto request ) {
		
		BuyerLoginResponseDto response = buyerService.checkBuyerLogin(request);
		return response;
	}
	

	@GetMapping("/addCheckout")
	public AddCheckoutResponseDto getcheckoutById(@RequestParam int cartId ) {
	
		boolean isSave = false;
		isSave = buyerService.getCheckoutById(cartId);
		System.out.println("IsSave-->"+isSave);
		AddCheckoutResponseDto response = new AddCheckoutResponseDto();	
		if(isSave == true) {
			response.setCode("200");
			response.setMessgae("product is purchased");
		} else {
			response.setCode("201");
			response.setMessgae("product not purchased");	
		}
	
		return response;
	}
	
	@GetMapping(value = "/checkoutById/{id}")
	public List<Checkout> findCheckoutById(@PathVariable int id) {

		List<Checkout> customers = buyerService.findByCheckoutId(id);
		return customers;
	}
	
	
	@GetMapping(value = "/getCheckoutHistory")
	public List<CheckoutResponseDto>  getAllCheckout() {

		List<CheckoutResponseDto> customers = buyerService.getCheckoutHistory();
		return customers;
	}	
	
	@GetMapping("/getProductbyId")
	public GetProductReponseDto getProductById(@RequestParam int productId ) {
		
		RestTemplate restTemplate = new RestTemplate();
		
	     
	    //final String baseUrl = "http://localhost:8998/seller/getProductbyId?productId= "+productId+"";
		//getProductbyId?productId=2
		
		final String baseUrl = "http://localhost:8998/seller/getProductbyId?productId="+productId+"";
		
	    URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 //System.out.println("here "+uri);
		 ResponseEntity<GetProductReponseDto> result=restTemplate.getForEntity(uri, GetProductReponseDto.class);
		 
		 GetProductReponseDto response=result.getBody();
		
	 //   ResponseEntity<GetProductReponseDto> result = restTemplate.getForEntity(uri, String.class);
	     
	    //Verify request succeed
	  //  System.out.println("Status code: "+result.getStatusCodeValue());
	  //  System.out.println("result: "+result.getBody());
	    
		return response;
	}
	
	 
	@GetMapping("/getProductbyKeywords")
	public List<GetProductReponseDto> seachByProductKeywords(@RequestParam String productName ) {
	
		RestTemplate restTemplate = new RestTemplate();
		
		final String baseUrl = "http://localhost:8998/seller/getProductbyKeywords?productName="+productName+"";
		
	    URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     ResponseEntity<List<GetProductReponseDto>> responseEntity = restTemplate.exchange(uri,HttpMethod.GET,null,
	    		    new ParameterizedTypeReference<List<GetProductReponseDto>>() {});
	    		
	     List<GetProductReponseDto> GetProductReponse = responseEntity.getBody();
	     
		return GetProductReponse;
	}
	
	
	@PostMapping("/getAllProduct")
	public List<AllProductListReponseDto>  getAllProduct(@RequestBody GetAllProductReqDto req) {
		
		
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<String>(new Gson().toJson(req), headers);
		
		final String baseUrl="http://localhost:8998/seller/getAllProduct";
	   
		    URI uri =  null;
			try {
				uri = new URI(baseUrl);
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
			 ResponseEntity<List<AllProductListReponseDto>> responseEntity = restTemplate.exchange(uri,HttpMethod.POST,entity,
		    		    new ParameterizedTypeReference<List<AllProductListReponseDto>>() {});
		    		
		     List<AllProductListReponseDto> GetAllProductReponse = responseEntity.getBody();
			
		return GetAllProductReponse;
	}
	
}
