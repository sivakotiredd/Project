package com.buyer.buyer.model;

public class AddCheckoutResponseDto {

private String code;
	
	private String messgae;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessgae() {
		return messgae;
	}

	public void setMessgae(String messgae) {
		this.messgae = messgae;
	}

	@Override
	public String toString() {
		return "AddCheckoutResponseDto [code=" + code + ", messgae=" + messgae + "]";
	}
	

}
