package com.buyer.buyer.model;

public class BuyerCreateAccountResponseDto {

	private String code;
	
	private String messgae;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessgae() {
		return messgae;
	}

	public void setMessgae(String messgae) {
		this.messgae = messgae;
	}

	@Override
	public String toString() {
		return "sellerCreateAccountResponseDto [code=" + code + ", messgae=" + messgae + "]";
	}
	
	
	
}
