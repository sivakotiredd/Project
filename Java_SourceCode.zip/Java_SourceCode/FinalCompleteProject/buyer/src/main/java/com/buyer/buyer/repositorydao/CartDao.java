package com.buyer.buyer.repositorydao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.buyer.buyer.model.Buyer;
import com.buyer.buyer.model.Cart;

public interface CartDao extends JpaRepository<Cart, Integer> {
	
	
	@Query("From Cart s Where s.buyerId = :id")
	public List<Cart> findByBuyerId(@Param("id") int id);
	
	@Query("From Cart u Where u.cartId = :id")
	public List<Cart> findByCartId(@Param("id") int id);
	
	//@Query("From Cart s Where s.name = :sname")
	//public Cart findBySellerName(@Param("sname") String name);


}
