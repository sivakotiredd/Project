package com.buyer.buyer.repositorydao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.buyer.buyer.model.Cart;
import com.buyer.buyer.model.Checkout;

public interface CheckoutDao extends JpaRepository<Checkout,Integer>{

	@Query("From Checkout u Where u.cartId = :id")
	public List<Checkout> findByCheckoutId(@Param("id") int id);

}
