package com.buyer.buyer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.buyer.buyer.model.AddcartRequestDto;
import com.buyer.buyer.model.Buyer;
import com.buyer.buyer.model.BuyerCreateAccountRequestDto;
import com.buyer.buyer.model.BuyerLoginRequestDto;
import com.buyer.buyer.model.BuyerLoginResponseDto;
import com.buyer.buyer.model.Cart;
import com.buyer.buyer.model.Checkout;
import com.buyer.buyer.model.CheckoutResponseDto;
import com.buyer.buyer.repositorydao.BuyerDao;
import com.buyer.buyer.repositorydao.CartDao;
import com.buyer.buyer.repositorydao.CheckoutDao;


@Service
public class BuyerServiceImpl implements BuyerService {

	@Autowired
	BuyerDao buyerDao;
	
	@Autowired
	CartDao cartDao;

	@Autowired
	CheckoutDao checkoutDao;
	
	public boolean createSeller(BuyerCreateAccountRequestDto request) {

		boolean isSave = false;

		try {

			Buyer buyer = new Buyer();
			buyer.setAddress(request.getAddress());
			buyer.setEmailId(request.getEmailId());
			buyer.setName(request.getSellerName());
			buyer.setPassword(request.getPassword());
			buyer.setPhoneNumber(request.getPhoneNumber());
			buyer.setUsername(request.getUserName());
			buyerDao.save(buyer);
			isSave = true;
		} catch (Exception e) {
			isSave = false;
		}
		return isSave;
	}

	public boolean addProduct(AddcartRequestDto req) {

		boolean isSave = false;

		try {
			Cart cart = new Cart();
			cart.setSellerId(req.getSellerId());
			cart.setSellerName(req.getSellerName());
			cart.setBuyerId(req.getBuyerId());
			cart.setPrice(req.getPrice());
			cart.setProductId(req.getProductId());
			cart.setProductName(req.getProductName());
			cart.setPurchaseQuantity(req.getPurchaseQuantity());
			Buyer buyer = buyerDao.findIdByName(req.getUserName());
			cart.setBuyer(buyer);
			cartDao.save(cart);
			isSave = true;
		} catch (Exception e) {
			isSave = false;
		}

		return isSave;
	}

	@Override
	public List<Cart> findByBuyerId(int id) {
		List<Cart> cart = cartDao.findByBuyerId(id);
		return cart;
	}

	@Override
	public boolean deleteCart(int cartId){
		
		boolean isSave=false;
		try {
		cartDao.deleteById(cartId);
		isSave =true;
		} catch (Exception e) {
		isSave= false;	
		}
		return isSave;
	}

	@Override
	public BuyerLoginResponseDto checkBuyerLogin(BuyerLoginRequestDto buyerRequest) {
		
		boolean isValid=false;
		BuyerLoginResponseDto response = new BuyerLoginResponseDto();
		try {
		int count = buyerDao.findByUsernamePassword(buyerRequest.getUsername(),buyerRequest.getPassword());
		System.out.println("Count->"+count);	
		if(count ==1) {
			isValid = true;
			}
		} catch (Exception e) {
		isValid	= false;
		}
		
		response.setValidCred(isValid);
		if(isValid == true) {
			 Buyer buyer =buyerDao.findIdByName(buyerRequest.getUsername());
			 System.out.println("buyer117->"+buyer.getName());		
			 response.setAddress(buyer.getAddress());
			 response.setEmailId(buyer.getEmailId());
			 response.setName(buyer.getName());
			 response.setPhoneNumber(buyer.getPhoneNumber());
			 response.setBuyerId(buyer.getBuyerId());
			 response.setUsername(buyer.getUsername());
			 response.setValidCred(isValid);
			 
			
		}
		
		return response;

	}

	@Override
	public boolean getCheckoutById(int cartId){
		System.out.println("CartId->"+cartId);	
		Checkout response = new Checkout();
		boolean isSave = false;
		try {
		List<Cart> p= cartDao.findByCartId(cartId);
		System.out.println("List<CartId->"+p.size());
		for( int i = 0;i<p.size();i++) {
			System.out.println("CartTableCartId->"+p.get(i).getCartId());
			System.out.println("CartTableBuyerId->"+p.get(i).getBuyerId());
		if(p.get(i).getCartId() == cartId) {
			System.out.println("CartData->"+p.get(i).getSellerName());
			response.setCartId(cartId);
			response.setPrice(p.get(i).getPrice());
			response.setProductId(p.get(i).getProductId());
			response.setProductName(p.get(i).getProductName());
			response.setPurchaseQuantity(p.get(i).getPurchaseQuantity());
			response.setSellerName(p.get(i).getSellerName());
			response.setSellerId(p.get(i).getSellerId());
			Optional<Buyer> buyer = buyerDao.findById(p.get(i).getBuyerId());
			response.setBuyer(buyer.get());
			checkoutDao.save(response);
		}
			
		}
		isSave = true;
		}		
		catch(Exception e) {
			isSave = false;
			response = null;
		}
		
		return isSave; 
			
	}

	@Override
	public List<Checkout> findByCheckoutId(int id) {
		List<Checkout> checkout = checkoutDao.findByCheckoutId(id);
		return checkout;
	}

	public List<CheckoutResponseDto> getCheckoutHistory() {
		
		List<CheckoutResponseDto> productResponseList = new ArrayList<CheckoutResponseDto>();
		
		List<Checkout> productList=checkoutDao.findAll();
		
		CheckoutResponseDto productResponse=null;
		
		for(Checkout p: productList) {
			productResponse= new CheckoutResponseDto();
			productResponse.setPrice(p.getPrice());
			productResponse.setProductId(p.getProductId());
			productResponse.setProductName(p.getProductName());
			productResponse.setProductName(p.getProductName());
			productResponse.setCartId(p.getCartId());
			productResponse.setSellerName(p.getSellerName());
			productResponse.setSellerId(p.getSellerId());
			productResponse.setPurchaseQuantity(p.getPurchaseQuantity());
			productResponseList.add(productResponse);
			}
		return productResponseList;
	}

}
