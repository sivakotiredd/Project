package com.buyer.buyer.repositorydao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.buyer.buyer.model.Buyer;

public interface BuyerDao extends JpaRepository<Buyer, Integer> {

	@Query("From Buyer s Where s.username = :userName")
	public Buyer findIdByName(@Param("userName") String name);
	
	@Query("select count(s) From Buyer s Where s.username = :userName and s.password = :password")
	public int findByUsernamePassword(@Param("userName") String userName , @Param("password") String password);  
	
	@Query("From Buyer s Where s.name = :sname")
	public Buyer findByBuyerName(@Param("sname") String name);
	
	
	
}
