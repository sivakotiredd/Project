package com.buyer.buyer.service;

import java.util.List;

import com.buyer.buyer.model.AddcartRequestDto;
import com.buyer.buyer.model.BuyerCreateAccountRequestDto;
import com.buyer.buyer.model.BuyerLoginRequestDto;
import com.buyer.buyer.model.BuyerLoginResponseDto;
import com.buyer.buyer.model.Cart;
import com.buyer.buyer.model.Checkout;
import com.buyer.buyer.model.CheckoutResponseDto;

public interface BuyerService {

	public boolean createSeller(BuyerCreateAccountRequestDto request);

	public boolean addProduct(AddcartRequestDto req);

	public List<Cart> findByBuyerId(int id);
	
	public boolean deleteCart(int cartId);

	public BuyerLoginResponseDto checkBuyerLogin(BuyerLoginRequestDto buyerRequest);
	
	public boolean getCheckoutById(int cartId);
	
	public List<Checkout>findByCheckoutId(int id);
	
	public List<CheckoutResponseDto> getCheckoutHistory();

}
