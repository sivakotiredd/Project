package com.buyer.buyer.model;


public class GetProductReponseDto {
	
    private int productId;
	
	private String productName;
	
	private String model;
	
	private String make;
	
	private String categoryId;
	
	private String subcategoryId;
	
	private int price;
	
	private int quantity;
	
	private String image;
	
    private String specification;
	
	private boolean status;
	
	private Seller seller;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getSubcategoryId() {
		return subcategoryId;
	}

	public void setSubcategoryId(String subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	@Override
	public String toString() {
		return "GetProductReponseDto [productId=" + productId + ", productName=" + productName + ", model=" + model
				+ ", make=" + make + ", categoryId=" + categoryId + ", subcategoryId=" + subcategoryId + ", price="
				+ price + ", quantity=" + quantity + ", image=" + image + ", specification=" + specification
				+ ", status=" + status + ", seller=" + seller + "]";
	}

	
	
	
}
